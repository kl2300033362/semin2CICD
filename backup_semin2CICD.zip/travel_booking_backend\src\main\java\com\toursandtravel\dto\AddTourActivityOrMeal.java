package com.toursandtravel.dto;

import lombok.Data;

@Data
public class AddTourActivityOrMeal {

	private String name;

	private String description;

	private Integer tourId;

}
