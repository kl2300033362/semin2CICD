package com.toursandtravel.service;

import com.toursandtravel.entity.Payment;

public interface PaymentService {

	Payment addPayment(Payment payment);

}
